<?php
 if (isset($_POST['submit'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $remember = $_POST['remember'];
 }
 else {
   header("location: loginpage.php");
 }
 ?>
