<?php include('login/login.php'); 
if (empty($_SESSION['username'])) {
  header('location: loginpage.php');
  exit();
}
if (isset($_GET['logout'])) {
 session_start();
 session_destroy();
 $_SESSION = array();
 header("location: loginpage.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>MaterialAdminLTE 2 | Widgets</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <script type="text/javascript" src = "../bootstrap/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../plugins/font-awesome/css/font-awesome.css">
  <!-- Font Awesome -->
  <script type="text/javascript" src="../plugins/materialize-css/js/materialize.js"></script>
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- Material Design -->
<!--  <link rel="stylesheet" href="dist/css/bootstrap-material-design.min.css">-->
  <link rel="stylesheet" href="../dist/css/ripples.min.css">
  <link rel="stylesheet" href="../dist/css/MaterialAdminLTE.min.css">
  <!-- MaterialAdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/all-md-skins.min.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-purple sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="emphome.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b><b>R</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Human</b> <b>Resource</b></span>
    </a>
  <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <div class="nav nav-bar">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../dist/img/avatar5.png" class="user-image" alt="User Image">
              <span class="hidden-xs">Ashebr Belay</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../dist/img/avatar5.png" class="img-circle" alt="User Image">
              </li>
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <!--<li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>-->
        </ul>
      </div>
    </nav>  
  </header>



  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Ashebr Belay</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <ul class="sidebar-menu">

<!--/////////////////////////////////////////////Home//////////////////////////////////////////////////////////////-->

         <li class="active">
          <a href="emphome.php">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>
<!--//////////////////////////////////////////// My Infor ////////////////////////////////////////////////////////--> 

   <li><a href="empinfo/mypersonaldetail.php"><i class="fa fa-info-circle"></i> <span>View My Information</span></a></li>

<!--/////////////////////////////////////////////Leaves//////////////////////////////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-eject"></i> <span>Leave</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class = "treeview-menu">
             <li><a href="empleave/myentitlement.php"><i class="fa fa-circle-o"></i>May Entitlements</a></li>  
             <li><a href="empleave/myreport.php"><i class="fa fa-circle-o"></i>My Leave Report</a></li>
             <li><a href="empleave/myleave.php"><i class="fa fa-circle-o"></i>My Leave</a></li>
             <li><a href="empleave/applay.php"><i class="fa fa-circle-o"></i>Apply</a></li> 
          </ul>
        </li>

<!--/////////////////////////////////////////////Times//////////////////////////////////////////////////////////////-->

         <li class="treeview">
          <a href="#">
            <i class="fa fa-clock-o"></i> <span>Time</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
                 <li><a href="emptime/mytimesheet.php"><i class="fa fa-circle-o"></i>My Timesheets</a></li>
                <li><a href="emptime/myrecord.php"><i class="fa fa-circle-o"></i>My Records</a></li>
                <li><a href="emptime/mypunch.php"><i class="fa fa-circle-o"></i>Punch In/Out</a></li>
           </ul>
            </li>


<!--/////////////////////////////////////////////Performance/////////////////////////////////////////////////////////////-->
        
        <li class="treeview">
          <a href="#">
            <i class="fa fa-hand-lizard-o"></i> <span>Performance</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li><a href="emperformance/myreview.php"><i class="fa fa-circle-o"></i>My Reviews</a></li>
              <li><a href="emperformance/myreviewlist.php"><i class="fa fa-circle-o"></i>Review List</a></li>
              <li><a href="emperformance/mytracker.php"><i class="fa fa-circle-o"></i>My Tracker</a></li>
              <li><a href="emperformance/emptracker.php"><i class="fa fa-circle-o"></i>Employee Trackers</a></li>
          </ul>
        </li>

<!--/////////////////////////////////////////////Quick Search/////////////////////////////////////////////////////////////-->
       
        <li><a href="empdirectory.php"><i class="fa fa-search-plus"></i> <span>Directories</span></a></li>
    </ul>
  </section>
    <!-- /.sidebar -->
</aside>


  <div class="content-wrapper">
    <section class="content-header">
      <h1 style = "margin-bottom:20px"></h1>
      <ol class="breadcrumb">
      </ol>
    </section>

  <!--////////////////////// Main content/////////////////////////////////////////////////////////////////////////////-->
    <section class="content">
       
    <div class="container-fluid">       
   


 
  </div>  
  </section>
</div>
  <!--/////////////////////////////Control Sidebar/////////////////////////////////////////////////////////////////////-->
  <aside class="control-sidebar control-sidebar-dark">
      <div class="tab-pane" id="control-sidebar-home-tab"></div>
  </aside>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017 <a href="#"></a>All rights
    reserved.
  </footer>
</div>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="../dist/js/material.min.js"></script>
<script src="../dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- Slimscroll -->
<script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
</body>
</html>
