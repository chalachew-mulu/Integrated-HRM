
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Amhara Mass Media Agency</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="../../../bootstrap/css/bootstrap.min.css">
    <link rel="shortcut icon" href="../../../dist/img/amma1.jpg">
    <link rel="stylesheet" type="text/css" href="../../../plugins/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../../../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../../../dist/css/ripples.min.css">
    <link rel="stylesheet" href="../../../dist/css/MaterialAdminLTE.min.css">
    <link rel="stylesheet" href="../../../dist/css/skins/all-md-skins.min.css">
</head>
<body class="hold-transition skin-purple sidebar-mini">
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="../../adminhome.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b><b>R</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Human</b> <b>Resource</b></span>
    </a>
  <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <div class="nav nav-bar">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../../../dist/img/avatar5.png" class="user-image" alt="User Image">
              <span class="hidden-xs">Ashebr Belay</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../../../dist/img/avatar5.png" class="img-circle" alt="User Image">
              </li>
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <!--<li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>-->
        </ul>
      </div>
    </nav>
  </header>

  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../../../dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Ashebr Belay</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <ul class="sidebar-menu">
        <li class="header">EMPLOYEE MANAGEMENET</li>

<!--/////////////////////Home//////////////////////////////////////////-->

         <li class="active">
          <a href="../../adminhome.php">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>

<!--////////////////////////Admin////////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user-secret"></i> <span>Admin</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>User Management
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../manageuser/adduser.php"><i class="fa fa-circle-o"></i>Users</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Job
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="jobtitle.php"><i class="fa fa-circle-o"></i>Job Title</a></li>
                <li><a href="paygrade.php"><i class="fa fa-circle-o"></i>Pay Grades</a></li>
                <li><a href="empstatus.php"><i class="fa fa-circle-o"></i>Employment Status</a></li>
                <li><a href="jobcategory.php"><i class="fa fa-circle-o"></i>Job Catigories</a></li>
                <li><a href="workshift.php"><i class="fa fa-circle-o"></i>Work Shifts</a></li>
              </ul>
            </li>

             <li>
              <a href="#"><i class="fa fa-circle-o"></i>Organization
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
              <li><a href="../organization/generalinfo.php"><i class="fa fa-circle-o"></i>General Information</a></li>
                <li><a href="../organization/location.php"><i class="fa fa-circle-o"></i>Location</a></li>
              </ul>
            </li>

             <li>
              <a href="#"><i class="fa fa-circle-o"></i>Qualification
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
               <li><a href="../qualification/skill.php"><i class="fa fa-circle-o"></i>Skills</a></li>
                <li><a href="../qualification/education.php"><i class="fa fa-circle-o"></i>Education</a></li>
                <li><a href="../qualification/language.php"><i class="fa fa-circle-o"></i>Language</a></li>
                <li><a href="../qualification/license.php"><i class="fa fa-circle-o"></i>Licenses</a></li>
                <li><a href="../qualification/member.php"><i class="fa fa-circle-o"></i>Memberships</a></li>
              </ul>
            </li>

              <li><a href="../nationality/nationality.php"><i class="fa fa-circle-o"></i>Nationality</a></li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configurations
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
          <ul class="treeview-menu">
            <li><a href="../configuration/emailconfigure.php"><i class="fa fa-circle-o"></i>Email Cofiguration</a></li>
            <li><a href="../configuration/emailsubscribe.php"><i class="fa fa-circle-o"></i>Email Subscription</a></li>
            <li><a href="../configuration/localization.php"><i class="fa fa-circle-o"></i>Localization</a></li>
            <li><a href="../configuration/module.php"><i class="fa fa-circle-o"></i>Modules</a></li>
            <li><a href="../configuration/socialmedia.php"><i class="fa fa-circle-o"></i>Sociall Media Authentication</a></li>
            <li><a href="../configuration/registerclient.php"><i class="fa fa-circle-o"></i>Register OAuth Client</a></li>
              </ul>
            </li>
          </ul>
        </li>

<!--//////////////////////Manage Employee//////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Manage Employee</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configurations
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
        <ul class="treeview-menu">
          <li><a href="../../managemp/configure/field.php"><i class="fa fa-circle-o"></i>Optional Fields</a></li>
          <li><a href="../../managemp/configure/custom.php"><i class="fa fa-circle-o"></i>Custom Fields</a></li>
          <li><a href="../../managemp/configure/iport.php"><i class="fa fa-circle-o"></i>Data Import</a></li>
          <li><a href="../../managemp/configure/reportmethod.php"><i class="fa fa-circle-o"></i>Reporting Methods</a></li>
          <li><a href="../../managemp/configure/terminatereason.php"><i class="fa fa-circle-o"></i>Termination Reasons</a></li>
        </ul>
            </li>
            <li><a href="../../managemp/emplist.php"><i class="fa fa-circle-o"></i>Employee List</a></li>
            <li><a href="../../managemp/personaldetail.php"><i class="fa fa-circle-o"></i>Add Employee</a></li>
            <li><a href="../../managemp/report.php"><i class="fa fa-circle-o"></i>Reports</a></li>
          </ul>
        </li>

<!--////////////////////////Leaves//////////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-eject"></i> <span>Leave</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Entitlements
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
        <ul class="treeview-menu">
          <li><a href="../../eave/entitlement/addentitlement.php"><i class="fa fa-circle-o"></i>Add Entitlements</a></li>
          <li><a href="../../leave/entitlement/leaventitlement.php"><i class="fa fa-circle-o"></i>Employee Entitlements</a></li>
        </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Reports
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../leave/report/report.php"><i class="fa fa-circle-o"></i>Usage Report</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configure
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../leave/configure/leaveperiod.php"><i class="fa fa-circle-o"></i>Leave Period</a></li>
                <li><a href="../../leave/configure/leavetype.php"><i class="fa fa-circle-o"></i>Leave Types</a></li>
                <li><a href="../../leave/configure/workweek.php"><i class="fa fa-circle-o"></i>Work Week</a></li>
                <li><a href="../../leave/configure/holiday.php"><i class="fa fa-circle-o"></i>Holidays</a></li>
              </ul>
            </li>
           <li><a href="../../leave/leavelist.php"><i class="fa fa-circle-o"></i>Leave List</a></li>
            <li><a href="../../leave/assignleave.php"><i class="fa fa-circle-o"></i>Assign Leave</a></li>
          </ul>
        </li>

<!--///////////////Times////////////////////////////////////////////-->

         <li class="treeview">
          <a href="#">
            <i class="fa fa-clock-o"></i> <span>Time</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Time Sheets
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                 <li><a href="../../time/timesheet/timesheet.php"><i class="fa fa-circle-o"></i>Add Timesheets</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Attendance
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../time/attendance/attendance.php"><i class="fa fa-circle-o"></i>Employee Records</a></li>
                <li><a href="../../time/attendance/configure.php"><i class="fa fa-circle-o"></i>Configurations</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Reports
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../time/report/projectreport.php"><i class="fa fa-circle-o"></i>Project Reports</a></li>
                <li><a href="../../time/report/empreport.php"><i class="fa fa-circle-o"></i>Employee Reports</a></li>
               <li><a href="../../time/report/attendancereport.php"><i class="fa fa-circle-o"></i>Attendance Summary</a></li>
              </ul>
           </li>

           <li>
              <a href="#"><i class="fa fa-circle-o"></i>Project Information
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../time/projectinfo/customer.php"><i class="fa fa-circle-o"></i>Customers</a></li>
                <li><a href="../../time/projectinfo/project.php"><i class="fa fa-circle-o"></i>Projects</a></li>
              </ul>
           </li>
          </ul>
        </li>

<!--///////////////////////Recruitment///////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-street-view"></i> <span>Manage Recruitment</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="../../managerecruit/candidate.php"><i class="fa fa-circle-o"></i>Candidates</a></li>
            <li><a href="../../managerecruit/vacancy.php"><i class="fa fa-circle-o"></i>Vacancies</a></li>
          </ul>
        </li>

<!--////////////////////Performance/////////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-hand-lizard-o"></i> <span>Performance</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configure
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../performance/configure/configurekpi.php"><i class="fa fa-circle-o"></i>KPIs </a></li>
                <li><a href="../../performance/configure/configuretracker.php"><i class="fa fa-circle-o"></i>Trackers</a></li>
              </ul>
            </li>
             <li><a href="../../performance/managereview.php"><i class="fa fa-circle-o"></i>Manage Reviews</a></li>
            <li><a href="../../performance/emptracker.php"><i class="fa fa-circle-o"></i>Employee Trackers</a></li>
          </ul>
        </li>

<!--////////////////////Quick Search//////////////////////////////-->

        <li><a href="directory.php"><i class="fa fa-search-plus"></i> <span>Directories</span></a></li>

<!--////////////////////other Acions///////////////////////////-->
      <li class="header">Other Actions</li>
      <li><a href="../../driver.php"><i class="fa fa-circle-o text-red"></i> <span>Send SMS For Driver</span></a></li>
      <li><a href="../../journal.php"><i class="fa fa-circle-o text-yellow"></i> <span>Send SMS For Journalists</span></a></li>
      <li><a href="../../print.php"><i class="fa fa-circle-o text-aqua"></i> <span>Print Report</span></a></li>
    </ul>
  </section>
    <!-- /.sidebar -->
</aside>
  <div class="content-wrapper">
    <section class="content-header">
      <h1 style = "margin-bottom:20px"></h1>
      <ol class="breadcrumb">
      </ol>
    </section>

  <!--////////////////////// Main content//////////////////////////-->
<section class="content">
  <div class="container-fluid">
    <div class="panel box box-primary">
      <form  action="#" method="post" autocomplete="honorific-prefix" enctype="multipart/form-data">
      <div class="box-header with-border">
      <div id ="load"><h4>Work Shift</h4></div>
      <div id ="read" style="display:none"><h4>Add Work Shift</h4></div>
      </div>
      <div class="box-body">
        <div id="btn-add">
          <button type="button" class="btn btn-default" id="add-click"> Add
          <i class="fa fa-plus-circle"></i></button>
        </div>

        <div id="formpage" style="display:none">
          <div class="row">
            <div class="col-md-10">
              <div class="form-group">
                <label class="control-label col-xs-2">Shift Name</label>
                <div class="col-md-8">
                  <input type="text" name="name" class="form-control" placeholder="Name" required>
                </div>
              </div>
            </div>
          </div><br>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label class="control-label col-xs-2">Work Hours</label>
                <div class="col-md-8">
                  <label class="control-label col-xs-1">From</label>
                  <div class="col-md-2">
                    <input type="time" name="From" class="form-control">
                  </div>
                  <label class="control-label col-xs-1">To</label>
                  <div class="col-md-2">
                    <input type="time" name="To" class="form-control">
                  </div>
                  <label  class="control-label col-xs-1">Duration</label>
                  <div class="col-md-2">
               <input type="text" name="duration" readonly class="form-control">
                  </div>
                </div>
              </div>
            </div>
          </div><br>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label>Available Employee</label>
                <textarea name="name" rows="10" cols="50" readonly placeholder="ads"></textarea>
              </div>
            </div>
            <div class="col-md-2">
              <br><br><br><br><br>
              <label>Add >></label><br>
              <label>Remove <<</label>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>Assigned Employee</label>
                <textarea name="name" rows="10" cols="50" readonly placeholder="ads" disabled></textarea>
              </div>
            </div>
          </div><br>
        </div>
        <div id="tablelist" class="table-responsive">
          <table class = "table table-striped table-bordered table-hover table-condensed">
           <thead class="bg-gray">
             <tr>
               <th>Shift Name</th>
               <th>From</th>
               <th>To</th>
               <th>Hours Per Day</th>
             </tr>
           </thead>
           <tbody>
             <tr>
             </tr>
           </tbody>
          </table>
        </div>
      </div>
      <div id="footer" style="display:none">
        <div class="box-footer clearfix">
          <button type="submit" class="btn btn-default" id="save">Save
           <i class="fa fa-save"></i></button>
            <button type="reset" class="btn btn-default" id="cancel-click">Cancel
           <i class="fa fa-times-circle"></i></button>
        </div>
     </div>
    </form>
    </div>
  </div>
</section>
</div>
  <!--///////////////////Control Sidebar////////////////////////////////-->
  <aside class="control-sidebar control-sidebar-dark">
      <div class="tab-pane" id="control-sidebar-home-tab"></div>
  </aside>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017 <a href="#"></a>All rights
    reserved.
  </footer>
</div>

<script src="../../../plugins/materialize-css/js/materialize.js"></script>
<script src = "../../../bootstrap/js/bootstrap.min.js"></script>
<script src="../../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="../../../bootstrap/js/bootstrap.min.js"></script>
<script src="../../../dist/js/material.min.js"></script>
<script src="../../../dist/js/ripples.min.js"></script>
<script>$.material.init();</script>
<script src="../../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="../../../plugins/fastclick/fastclick.js"></script>
<script src="../../../dist/js/app.min.js"></script>
<script src="../../../dist/js/demo.js"></script>
<script src="../../script.js"></script>
</body>
</html>
