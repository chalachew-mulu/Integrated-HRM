<?php 
   include('../../login/logout.php');
   session_start();  
   if (empty($_SESSION['username'])) {
   header('location: ../../loginpage.php');
  exit();
}?>
<?php 
 include('../../connection/connect.php');

 if (isset($_GET['id'])) {
   $id = $_GET['id'];
   $sql = "select * from hr_education where id ='".$id."'";
   $result2 = mysqli_query($con, $sql);
   if (mysqli_num_rows($result2) > 0) {
     $row = mysqli_fetch_array($result2);
   }
   else{
    $errormsg = 'Could Not Select Record';
   }
 }
 ////////update jo category//////////
 if (isset($_POST['update'])) {
   $name = $_POST['name'];
   if (empty($name)) {
     $errormsg = 'Enter Name to Update Please';
   }
  if (!isset($errormsg)) {
     $sql2 = "update hr_education set name = '".$name."' where id=".$id;
     $result3 = mysqli_query($con, $sql2);
     if ($result3) {
       $successmsg = 'Record Updated Successfuly !!';
       header('refresh:3;education.php');
     }
     else{
      $errormsg = "Error".mysqli_error($con);
     }
   } 
 }
 ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Amhara Mass Media Agency</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../../../bootstrap/css/bootstrap.min.css">
  <link rel="shortcut icon" href="../../../dist/img/amma1.jpg">
  <link rel="stylesheet"href="../../../plugins/font-awesome/css/font-awesome.css">
  <link rel="stylesheet" href="../../../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../../../dist/css/ripples.min.css">
  <link rel="stylesheet" href="../../../dist/css/MaterialAdminLTE.min.css">
  <link rel="stylesheet" href="../../../dist/css/skins/all-md-skins.min.css">
</head>
<body class="hold-transition skin-purple sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="../../adminhome.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b><b>R</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Human</b> <b>Resource</b></span>
    </a>
  <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <div class="nav nav-bar">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../../../dist/img/avatar5.png" class="user-image" alt="User Image">
                <?php if (isset($_SESSION["username"])): ?>
                  <span style="margin-right:10px">Welcome <?php echo ucwords($_SESSION['username']); ?></span>
                <?php endif ?>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../../../dist/img/avatar5.png" class="img-circle" alt="User Image">
              </li>
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="../../loginpage.php?logout='1'" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <!--<li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>-->
        </ul>
      </div>
    </nav>
  </header>



  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../../../dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <?php if (isset($_SESSION["username"])): ?>
            <p><?php echo ucwords($_SESSION['username']); ?></p>
          <?php endif ?>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <ul class="sidebar-menu">
        <li class="header">EMPLOYEE MANAGEMENET</li>

<!--///////////////////////Home///////////////////////////////////////-->

         <li class="active">
          <a href="../../adminhome.php">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>

<!--//////////////Admin////////////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user-secret"></i> <span>Admin</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>User Management
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../manageuser/adduser.php"><i class="fa fa-circle-o"></i>Users</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Job
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../job/jobtitle.php"><i class="fa fa-circle-o"></i>Job Title</a></li>
                <li><a href="../job/paygrade.php"><i class="fa fa-circle-o"></i>Pay Grades</a></li>
                <li><a href="../job/empstatus.php"><i class="fa fa-circle-o"></i>Employment Status</a></li>
                <li><a href="../job/jobcategory.php"><i class="fa fa-circle-o"></i>Job Catigories</a></li>
                <li><a href="../job/workshift.php"><i class="fa fa-circle-o"></i>Work Shifts</a></li>
              </ul>
            </li>

             <li>
              <a href="#"><i class="fa fa-circle-o"></i>Organization
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
              <li><a href="../organization/generalinfo.php"><i class="fa fa-circle-o"></i>General Information</a></li>
                <li><a href="../organization/location.php"><i class="fa fa-circle-o"></i>Location</a></li>
              </ul>
            </li>

             <li>
              <a href="#"><i class="fa fa-circle-o"></i>Qualification
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
               <li><a href="../qualification/skill.phph"><i class="fa fa-circle-o"></i>Skills</a></li>
                <li><a href="education.php"><i class="fa fa-circle-o"></i>Education</a></li>
                <li><a href="../qualification/language.php"><i class="fa fa-circle-o"></i>Language</a></li>
                <li><a href="../qualification/license.php"><i class="fa fa-circle-o"></i>Licenses</a></li>
                <li><a href="../qualification/member.php"><i class="fa fa-circle-o"></i>Memberships</a></li>
              </ul>
            </li>

              <li><a href="../nationality/nationality.php"><i class="fa fa-circle-o"></i>Nationality</a></li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configurations
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
          <ul class="treeview-menu">
            <li><a href="../configuration/emailconfigure.php"><i class="fa fa-circle-o"></i>Email Cofiguration</a></li>
            <li><a href="../configuration/emailsubscribe.php"><i class="fa fa-circle-o"></i>Email Subscription</a></li>
            <li><a href="../configuration/localization.php"><i class="fa fa-circle-o"></i>Localization</a></li>
            <li><a href="../configuration/module.php"><i class="fa fa-circle-o"></i>Modules</a></li>
            <li><a href="../configuration/socialmedia.php"><i class="fa fa-circle-o"></i>Sociall Media Authentication</a></li>
            <li><a href="../configuration/registerclient.php"><i class="fa fa-circle-o"></i>Register OAuth Client</a></li>
              </ul>
            </li>
          </ul>
        </li>

<!--//////////////////////Manage Employee//////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Manage Employee</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configurations
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
        <ul class="treeview-menu">
          <li><a href="../../managemp/configure/field.php"><i class="fa fa-circle-o"></i>Optional Fields</a></li>
          <li><a href="../../managemp/configure/custom.php"><i class="fa fa-circle-o"></i>Custom Fields</a></li>
          <li><a href="../../managemp/configure/iport.php"><i class="fa fa-circle-o"></i>Data Import</a></li>
          <li><a href="../../managemp/configure/reportmethod.php"><i class="fa fa-circle-o"></i>Reporting Methods</a></li>
          <li><a href="../../managemp/configure/terminatereason.php"><i class="fa fa-circle-o"></i>Termination Reasons</a></li>
        </ul>
            </li>
            <li><a href="../../managemp/emplist.php"><i class="fa fa-circle-o"></i>Employee List</a></li>
            <li><a href="../../managemp/personaldetail.php"><i class="fa fa-circle-o"></i>Add Employee</a></li>
            <li><a href="../../managemp/report.php"><i class="fa fa-circle-o"></i>Reports</a></li>
          </ul>
        </li>

<!--/////////////////////////////////////////////Leaves//////////////////////////////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-eject"></i> <span>Leave</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Entitlements
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
        <ul class="treeview-menu">
          <li><a href="../../eave/entitlement/addentitlement.php"><i class="fa fa-circle-o"></i>Add Entitlements</a></li>
          <li><a href="../../leave/entitlement/leaventitlement.php"><i class="fa fa-circle-o"></i>Employee Entitlements</a></li>
        </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Reports
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../leave/report/report.php"><i class="fa fa-circle-o"></i>Usage Report</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configure
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../leave/configure/leaveperiod.php"><i class="fa fa-circle-o"></i>Leave Period</a></li>
                <li><a href="../../leave/configure/leavetype.php"><i class="fa fa-circle-o"></i>Leave Types</a></li>
                <li><a href="../../leave/configure/workweek.php"><i class="fa fa-circle-o"></i>Work Week</a></li>
                <li><a href="../../leave/configure/holiday.php"><i class="fa fa-circle-o"></i>Holidays</a></li>
              </ul>
            </li>
           <li><a href="../../leave/leavelist.php"><i class="fa fa-circle-o"></i>Leave List</a></li>
            <li><a href="../../leave/assignleave.php"><i class="fa fa-circle-o"></i>Assign Leave</a></li>
          </ul>
        </li>

<!--////////////////////Times//////////////////////////////////////////////-->

         <li class="treeview">
          <a href="#">
            <i class="fa fa-clock-o"></i> <span>Time</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Time Sheets
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                 <li><a href="../../time/timesheet/timesheet.php"><i class="fa fa-circle-o"></i>Add Timesheets</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Attendance
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../time/attendance/attendance.php"><i class="fa fa-circle-o"></i>Employee Records</a></li>
                <li><a href="../../time/attendance/configure.php"><i class="fa fa-circle-o"></i>Configurations</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Reports
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../time/report/projectreport.php"><i class="fa fa-circle-o"></i>Project Reports</a></li>
                <li><a href="../../time/report/empreport.php"><i class="fa fa-circle-o"></i>Employee Reports</a></li>
               <li><a href="../../time/report/attendancereport.php"><i class="fa fa-circle-o"></i>Attendance Summary</a></li>
              </ul>
           </li>

           <li>
              <a href="#"><i class="fa fa-circle-o"></i>Project Information
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../time/projectinfo/customer.php"><i class="fa fa-circle-o"></i>Customers</a></li>
                <li><a href="../../time/projectinfo/project.php"><i class="fa fa-circle-o"></i>Projects</a></li>
              </ul>
           </li>
          </ul>
        </li>

<!--//////////////////////Recruitment//////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-street-view"></i> <span>Manage Recruitment</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="../../managerecruit/candidate.php"><i class="fa fa-circle-o"></i>Candidates</a></li>
            <li><a href="../../managerecruit/vacancy.php"><i class="fa fa-circle-o"></i>Vacancies</a></li>
          </ul>
        </li>

<!--//////////////////////Performance///////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-hand-lizard-o"></i> <span>Performance</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configure
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../performance/configure/configurekpi.php"><i class="fa fa-circle-o"></i>KPIs </a></li>
                <li><a href="../../performance/configure/configuretracker.php"><i class="fa fa-circle-o"></i>Trackers</a></li>
              </ul>
            </li>
             <li><a href="../../performance/managereview.php"><i class="fa fa-circle-o"></i>Manage Reviews</a></li>
            <li><a href="../../performance/emptracker.php"><i class="fa fa-circle-o"></i>Employee Trackers</a></li>
          </ul>
        </li>

<!--/////////////////////////Quick Search////////////////////////-->

        <li><a href="../../directory.php"><i class="fa fa-search-plus"></i> <span>Directories</span></a></li>

<!--///////////////other Acions////////////////////////-->
      <li class="header">Other Actions</li>
      <li><a href="../../driver.php"><i class="fa fa-circle-o text-red"></i> <span>Send SMS For Driver</span></a></li>
      <li><a href="../../journal.php"><i class="fa fa-circle-o text-yellow"></i> <span>Send SMS For Journalists</span></a></li>
      <li><a href="../../print.php"><i class="fa fa-circle-o text-aqua"></i> <span>Print Report</span></a></li>
    </ul>
  </section>
    <!-- /.sidebar -->
</aside>
  <div class="content-wrapper">
    <section class="content-header">
      <h1 style = "margin-bottom:20px"></h1>
      <ol class="breadcrumb">
      </ol>
    </section>

  <!--////////////////////// Main content////////////////////////////-->
<section class="content">
  <div class="container-fluid">
    <div class="panel box box-primary">
      <form  action="#" method="post" autocomplete="honorific-prefix" enctype="multipart/form-data">
      <div class="box-header with-border">
      <div id ="load"><h4>Edit Education</h4></div>
      </div>
      <div class="box-body">
        <br>
        <?php if (isset($errormsg)){
            ?>
             <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                <span class = "fa fa-times-circle"></span>
              </button>
               <span class="glyphicon glyphicon-danger">
                 <strong><?php echo $errormsg;?></strong>
               </span>
             </div>
              <?php
              }
              ?>

            <?php if (isset($successmsg)){
            ?>
             <div class="alert alert-success alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                <span class = "glyphicon glyphicon-ok"></span></button>
               <span class="glyphicon glyphicon-danger">
                 <strong><?php echo $successmsg;?>  Refreshing ...</strong>
               </span>
             </div>
              <?php
              }
              ?> 
        <div id="formpage">
          <div class="row">
            <div class="col-md-7">
              <div class="form-group">
                <label class="control-label col-xs-4">Level</label>
                <div class="col-md-8">
               <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo $row['name']; ?>">
                </div>
              </div>
            </div>
          </div><br>
        </div>
       <div id="tablelist" class="table-responsive" style="display:none">
          <table class = "table table-striped table-bordered table-hover table-condensed">
           <thead class="bg-gray">
             <tr>
               <th>ID</th>
               <th>Level</th>
               <th>Actions</th>
             </tr>
           </thead>  
         <?php 
           $sql1 = "select * from hr_education";
           $result1 = mysqli_query($con, $sql1);
           if (mysqli_num_rows($result1)) {
             while ($row=mysqli_fetch_array($result1)) {
          ?>         
        <tr>
          <td><?php echo $row['id']?></td>
          <td><?php echo ucwords($row['name'])?></td>
          <td class="pull-right">
            <a href="editeducation.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-xs">
              <span class="glyphicon glyphicon-pencil"></span>&nbsp;&nbsp;Edit
            </a>

            <a href="education.php?delete=<?php echo $row['id']; ?>"
                class="btn btn-danger btn-xs" onclick="return confirm('Are You Sure You Want to Delete This Record??')">
              <span class="glyphicon glyphicon-trash"></span>&nbsp;&nbsp;Delete
            </a>

          </td>
        </tr>
          <?php
             }
           }
          ?>
          </table>
        </div>
      </div>
      <div id="footer">
        <div class="box-footer clearfix">
          <button type="submit" class="btn btn-default" id="update" name="update">Updated
           <i class="fa fa-pencil"></i></button>
            <button type="reset" class="btn btn-default" id="cancel" name = "cancel">Cancel
           <i class="fa fa-times-circle"></i></button>
        </div>
     </div>
    </form>
    </div>
  </div>
</section>
</div>
  <!--/////////////////////////////Control Sidebar////////////-->
  <aside class="control-sidebar control-sidebar-dark">
      <div class="tab-pane" id="control-sidebar-home-tab"></div>
  </aside>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017 <a href="#"></a>All rights
    reserved.
  </footer>
</div>
<script src = "../../../bootstrap/js/bootstrap.min.js"></script>
<script src="../../../plugins/materialize-css/js/materialize.js"></script>
<script src="../../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="../../../bootstrap/js/bootstrap.min.js"></script>
<script src="../../../dist/js/material.min.js"></script>
<script src="../../../dist/js/ripples.min.js"></script>
<script>$.material.init();</script>
<script src="../../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="../../../plugins/fastclick/fastclick.js"></script>
<script src="../../../dist/js/app.min.js"></script>
<script src="../../../dist/js/demo.js"></script>
<script src="../../script.js"></script>
</body>
</html>
