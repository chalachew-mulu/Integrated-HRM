<?php
session_start();
$err ="";
include('connection/connect.php');
if (isset($_POST['submit'])) {
  if (empty($_POST['username'])||empty($_POST['password'])) {
$err = "Invalid Username or Password!";
  }
  else {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $que = "SELECT * FROM hr_user WHERE user_name = '$username' AND user_password = '$password'";
    $res = mysqli_query($con, $que);
    if (mysqli_num_rows($res) == 1) {
    $_SESSION['username']=$username;
    header('location: adminhome.php');
    }
    else {
     $err = "Invalid Username or Password!";
    }
  }

}
else if (isset($_POST['empsubmit'])) {
   if (empty($_POST['empusername'])||empty($_POST['emppassword'])) {
$err = "Invalid Username or Password!";
  }
  else {
    $empusername = mysqli_real_escape_string($con, $_POST['empusername']);
    $emppassword = mysqli_real_escape_string($con, $_POST['emppassword']);
    $que = "SELECT * FROM hr_user WHERE user_name = '$empusername' AND user_password = '$emppassword'";
    $res = mysqli_query($con, $que);
    if (mysqli_num_rows($res) == 1) {
    $_SESSION['empusername']=$username;
    header('location: emphome.php');
    }
    else {
     $err = "Invalid Username or Password!";
    }
  }
}
 ?>
