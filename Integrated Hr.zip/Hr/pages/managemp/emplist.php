<?php 
   include('../login/logout.php');
   session_start();  
   if (empty($_SESSION['username'])) {
   header('location: ../loginpage.php');
  exit();
}
 ?>
 <?php 
   include('../connection/connect.php');
  if (isset($_GET['delete'])) {
   $emp_number = $_GET['delete'];
   $sql = "delete from hr_employee where emp_number='$emp_number'";
   if (mysqli_query($con,$sql)) {
    $successmsg = 'Employee Whose Sequence Number '.$emp_number.' is Being Deleted';
    header('refresh:1;emplist.php');
   }
   else{
    $errormsg = "Error".mysqli_error($con);
   }
 }
  ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Amhara MAss Media Agency</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="shortcut icon" href="../../dist/img/amma1.jpg">
    <link rel="stylesheet" type="text/css" href="../../plugins/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../../dist/css/ripples.min.css">
    <link rel="stylesheet" href="../../dist/css/MaterialAdminLTE.min.css">
    <link rel="stylesheet" href="../../dist/css/skins/all-md-skins.min.css">
</head>
<body class="hold-transition skin-purple sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="../adminhome.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b><b>R</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Human</b> <b>Resource</b></span>
    </a>
  <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <div class="nav nav-bar">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../../dist/img/avatar5.png" class="user-image" alt="User Image">
             <?php if (isset($_SESSION["username"])): ?>
                  <span style="margin-right:10px">Welcome <?php echo ucwords($_SESSION['username']); ?></span>
             <?php endif ?>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../../dist/img/avatar5.png" class="img-circle" alt="User Image">
              </li>
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="../loginpage.php?logout='1'" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <!--<li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>-->
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../../dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <?php if (isset($_SESSION["username"])): ?>
            <p><?php echo ucwords($_SESSION['username']); ?></p>
          <?php endif ?>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <ul class="sidebar-menu">
        <li class="header">EMPLOYEE MANAGEMENET</li>

<!--///////////////////////////Home//////////////////////////////////////////-->

         <li class="active">
          <a href="../adminhome.php">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>

<!--/////////////////////////Admin//////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user-secret"></i> <span>Admin</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>User Management
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../admin/manageuser/adduser.php"><i class="fa fa-circle-o"></i>Users</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Job
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../admin/job/jobtitle.php"><i class="fa fa-circle-o"></i>Job Title</a></li>
                <li><a href="../admin/job/paygrade.php"><i class="fa fa-circle-o"></i>Pay Grades</a></li>
                <li><a href="../admin/job/empstatus.php"><i class="fa fa-circle-o"></i>Employment Status</a></li>
                <li><a href="../admin/job/jobcategory.php"><i class="fa fa-circle-o"></i>Job Catigories</a></li>
                <li><a href="../admin/job/workshift.php"><i class="fa fa-circle-o"></i>Work Shifts</a></li>
              </ul>
            </li>

             <li>
              <a href="#"><i class="fa fa-circle-o"></i>Organization
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
              <li><a href="../admin/organization/generalinfo.php"><i class="fa fa-circle-o"></i>General Information</a></li>
                <li><a href="../admin/organization/location.php"><i class="fa fa-circle-o"></i>Location</a></li>
              </ul>
            </li>

             <li>
              <a href="#"><i class="fa fa-circle-o"></i>Qualification
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
               <li><a href="../admin/qualification/skill.php"><i class="fa fa-circle-o"></i>Skills</a></li>
                <li><a href="../admin/qualification/education.php"><i class="fa fa-circle-o"></i>Education</a></li>
                <li><a href="../admin/qualification/language.php"><i class="fa fa-circle-o"></i>Language</a></li>
                <li><a href="../admin/qualification/license.php"><i class="fa fa-circle-o"></i>Licenses</a></li>
                <li><a href="../admin/qualification/member.php"><i class="fa fa-circle-o"></i>Memberships</a></li>
              </ul>
            </li>

              <li><a href="../admin/nationality/nationality.php"><i class="fa fa-circle-o"></i>Nationality</a></li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configurations
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
          <ul class="treeview-menu">
            <li><a href="../admin/configuration/emailconfigure.php"><i class="fa fa-circle-o"></i>Email Cofiguration</a></li>
            <li><a href="../admin/configuration/emailsubscribe.php"><i class="fa fa-circle-o"></i>Email Subscription</a></li>
            <li><a href="../admin/configuration/localization.php"><i class="fa fa-circle-o"></i>Localization</a></li>
            <li><a href="../admin/configuration/module.php"><i class="fa fa-circle-o"></i>Modules</a></li>
            <li><a href="../admin/configuration/socialmedia.php"><i class="fa fa-circle-o"></i>Sociall Media Authentication</a></li>
            <li><a href="../admin/configuration/registerclient.php"><i class="fa fa-circle-o"></i>Register OAuth Client</a></li>
              </ul>
            </li>
          </ul>
        </li>

<!--///////////////////////Manage Employee////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Manage Employee</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configurations
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
        <ul class="treeview-menu">
          <li><a href="field.php"><i class="fa fa-circle-o"></i>Optional Fields</a></li>
          <li><a href="custom.php"><i class="fa fa-circle-o"></i>Custom Fields</a></li>
          <li><a href="import.php"><i class="fa fa-circle-o"></i>Data Import</a></li>
          <li><a href="configure/reportmethod.php"><i class="fa fa-circle-o"></i>Reporting Methods</a></li>
          <li><a href="configure/terminatereason.php"><i class="fa fa-circle-o"></i>Termination Reasons</a></li>
        </ul>
            </li>
            <li><a href="emplist.php"><i class="fa fa-circle-o"></i>Employee List</a></li>
            <li><a href="personaldetail.php"><i class="fa fa-circle-o"></i>Add Employee</a></li>
            <li><a href="report.php"><i class="fa fa-circle-o"></i>Reports</a></li>
          </ul>
        </li>

<!--////////////////////Leaves///////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-eject"></i> <span>Leave</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Entitlements
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
        <ul class="treeview-menu">
          <li><a href="../leave/entitlement/addentitlement.php"><i class="fa fa-circle-o"></i>Add Entitlements</a></li>
          <li><a href="../leave/entitlement/leaventitlement.php"><i class="fa fa-circle-o"></i>Employee Entitlements</a></li>
        </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Reports
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../leave/report/report.php"><i class="fa fa-circle-o"></i>Usage Report</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configure
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../leave/configure/leaveperiod.php"><i class="fa fa-circle-o"></i>Leave Period</a></li>
                <li><a href="../leave/configure/leavetype.php"><i class="fa fa-circle-o"></i>Leave Types</a></li>
                <li><a href="../leave/configure/workweek.php"><i class="fa fa-circle-o"></i>Work Week</a></li>
                <li><a href="../leave/configure/holiday.php"><i class="fa fa-circle-o"></i>Holidays</a></li>
              </ul>
            </li>
           <li><a href="../leave/leavelist.php"><i class="fa fa-circle-o"></i>Leave List</a></li>
            <li><a href="../leave/assignleave.php"><i class="fa fa-circle-o"></i>Assign Leave</a></li>
          </ul>
        </li>

<!--/////////////////////Times///////////////////////////////////////////-->

         <li class="treeview">
          <a href="#">
            <i class="fa fa-clock-o"></i> <span>Time</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Time Sheets
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                 <li><a href="../time/timesheet/timesheet.php"><i class="fa fa-circle-o"></i>Add Timesheets</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Attendance
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../time/attendance/attendance.php"><i class="fa fa-circle-o"></i>Employee Records</a></li>
                <li><a href="../time/attendance/configure.php"><i class="fa fa-circle-o"></i>Configurations</a></li>
              </ul>
            </li>

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Reports
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../time/report/projectreport.php"><i class="fa fa-circle-o"></i>Project Reports</a></li>
                <li><a href="../time/report/empreport.php"><i class="fa fa-circle-o"></i>Employee Reports</a></li>
               <li><a href="../time/report/attendancereport.php"><i class="fa fa-circle-o"></i>Attendance Summary</a></li>
              </ul>
           </li>

           <li>
              <a href="#"><i class="fa fa-circle-o"></i>Project Information
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../time/projectinfo/customer.php"><i class="fa fa-circle-o"></i>Customers</a></li>
                <li><a href="../time/projectinfo/project.php"><i class="fa fa-circle-o"></i>Projects</a></li>
              </ul>
           </li>
          </ul>
        </li>

<!--////////////////////////Recruitment////////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-street-view"></i> <span>Manage Recruitment</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="../managerecruit/candidate.php"><i class="fa fa-circle-o"></i>Candidates</a></li>
            <li><a href="../managerecruit/vacancy.php"><i class="fa fa-circle-o"></i>Vacancies</a></li>
          </ul>
        </li>

<!--//////////////////////Performance////////////////////////////////-->

        <li class="treeview">
          <a href="#">
            <i class="fa fa-hand-lizard-o"></i> <span>Performance</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li>
              <a href="#"><i class="fa fa-circle-o"></i>Configure
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="../performance/configure/configurekpi.php"><i class="fa fa-circle-o"></i>KPIs </a></li>
                <li><a href="../performance/configure/configuretracker.php"><i class="fa fa-circle-o"></i>Trackers</a></li>
              </ul>
            </li>
             <li><a href="../performance/managereview.php"><i class="fa fa-circle-o"></i>Manage Reviews</a></li>
            <li><a href="../performance/emptracker.php"><i class="fa fa-circle-o"></i>Employee Trackers</a></li>
          </ul>
        </li>

<!--///////////////////////Quick Search///////////////////////////////////-->

        <li><a href="../directory.php"><i class="fa fa-search-plus"></i> <span>Directories</span></a></li>

<!--///////////////////////////other Acions////////////////////////-->
      <li class="header">Other Actions</li>
      <li><a href="../driver.php"><i class="fa fa-circle-o text-red"></i> <span>Send SMS For Driver</span></a></li>
      <li><a href="../journal.php"><i class="fa fa-circle-o text-yellow"></i> <span>Send SMS For Journalists</span></a></li>
      <li><a href="../print.php"><i class="fa fa-circle-o text-aqua"></i> <span>Print Report</span></a></li>
    </ul>
  </section>
    <!-- /.sidebar -->
</aside>
  <div class="content-wrapper">
    <section class="content-header">
      <h1 style = "margin-bottom:20px"></h1>
      <ol class="breadcrumb">
      </ol>
    </section>

  <!--////////////////////// Main content/////////////////////////////////-->
    <section class="content">

<div class="container-fluid">
    <form action="" method="post">

        <div class="panel box box-primary">
          <div class="box-header with-border bg-gray">
            <h4 class="box-title text-center">Employee Information</h4>
          </div>
          <div class="box-body">

          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label for = "fname">Employee Name</label>
                <input type = "text" class = "form-control" id = "fname" name = "fname" placeholder = "First Name">
              </div>
            </div>



         <div class="col-md-3">
          <div class="form-group">
              <label for="id">Employee ID</label>
              <input type="text" class="form-control" placeholder="ID" id = "id" name="id">
          </div>
         </div>

         <div class="col-md-3">
         <div class="form-group">
            <label>Employment Status</label>
            <select class="form-control" name = "status">
              <option>All</option>
            </select>
          </div>
        </div>


         <div class="col-md-3">
         <div class="form-group">
            <label>Include</label>
            <select class="form-control" name = "status">
              <option>Current Employee Only</option>
              <option>Current And Past Employees</option>
              <option>Past Employee Only</option>
            </select>
          </div>
        </div>
        </div>

       <div class="row">

          <div class="col-md-3">
          <div class="form-group">
            <label for = "fname">Supervisor Name</label>
            <input type = "text" class = "form-control"id="supervisor"name ="supervisor"placeholder="Supervisor">
          </div>
          </div>

        <div class="col-md-3">
         <div class="form-group">
            <label>Job Title</label>
            <select class="form-control" name = "job">
            <?php 
               $query = mysqli_query($con, "select job_title from hr_employee,hr_job_title
                                                          where 
                                                          hr_employee.job_title_code = hr_job_title.id");
               while ($row = mysqli_fetch_array($query))
                {
               ?>
             <option value ="<?php echo $row['emp_number']; ?>">
              <?php echo ucwords($row['job_title']); ?>
             </option>
             <?php 
             } 
            ?>
            </select>
          </div>
        </div>

        <div class="col-md-3">
         <div class="form-group">
            <label>Sub Unit</label>
            <select class="form-control" name = "unit">
              <option>All</option>
            </select>
          </div>
        </div>
        
         <div class="col-md-3">
         <div class="form-group">
            <label>Gender</label>
            <select class="form-control" name = "gender">
              <option selected>Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
        </div>
       </div>
    </div>
    <div class="box-footer clearfix">
      <button type="submit" class="btn btn-default" id="search" name="search">Search
       <i class="fa fa-search"></i></button>
        <button type="reset" class="btn btn-default" id="reset">Reset
       <i class="fa fa-refresh"></i></button>
    </div>
    </div>
  </form>




  <div class="panel box box-primary">
    <div class="box-body table-responsive">
        <a href="personaldetail.php" class="btn btn-default btn-flat">Add <i class="fa fa-plus-circle"></i></a>
        <br>
        <?php if (isset($errormsg)){
            ?>
             <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                <span class = "fa fa-times-circle"></span>
              </button>
               <span class="glyphicon glyphicon-danger">
                 <strong><?php echo $errormsg;?></strong>
               </span>
             </div>
              <?php
              }
              ?>

            <?php if (isset($successmsg)){
            ?>
             <div class="alert alert-success alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                <span class = "glyphicon glyphicon-ok"></span></button>
               <span class="glyphicon glyphicon-danger">
                 <strong><?php echo $successmsg;?>  Refreshing ...</strong>
               </span>
             </div>
              <?php
              }
              ?> 
      <table class = "table table-striped table-hover table-condensed">
        <thead class="bg-gray">
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>
            <th>Job Title</th>
            <th>Employment Status</th>
            <th>Sub Unit</th>
            <th>Supervisor</th>
            <th>Actions</th>
          </tr>
        </thead>
         <?php
          if (isset($_POST['search'])) {
          $fname = $_POST['fname'];
          $gender = $_POST['gender'];
          $id = $_POST['id'];
          $status = $_POST['status'];
          $sql = "select * from hr_employee where emp_firstname='$fname' 
                                               or employee_id='$id' 
                                               or emp_gender='$gender'
                                               or emp_status='$status'";
          $search = mysqli_query($con, $sql);
          if (mysqli_num_rows($search)) {
            while ($row=mysqli_fetch_array($search)) {
         ?>
        <tr> 
         <td><?php echo $row['employee_id']; ?></td>
         <td><?php echo ucwords($row['emp_firstname']); ?></td>
         <td><?php echo ucwords($row['emp_middle_name']); ?></td>
         <td><?php echo ucwords($row['emp_lastname']); ?></td>
         <td><?php echo ucwords($row['job_title_code']); ?></td>
         <td></td>
         <td></td>
         <td></td>
         <td class="pull-right">
            <a href="personaldetail.php?id=<?php echo $row['emp_number']; ?>" class="btn btn-info btn-xs">
              <span class = "glyphicon glyphicon-pencil">
              </span>&nbsp;&nbsp;Edit
            </a>

            <a href="emplist.php?delete=<?php echo $row['emp_number']; ?>" 
              class="btn btn-danger btn-xs" onclick="return confirm('Are You Sure You Delete This Record')">
              <span class = "glyphicon glyphicon-trash">
              </span>&nbsp;&nbsp;Delete
            </a>
         </td>
        </tr> 

        <?php      
          }
        }
          }
         else{ 
        $sql = "select * from hr_employee";
        $result = mysqli_query($con, $sql);
        if (mysqli_num_rows($result)) {
          while ($row = mysqli_fetch_array($result)) {
         ?>
        <tr> 
         <td><?php echo $row['employee_id']; ?></td>
         <td><?php echo ucwords($row['emp_firstname']); ?></td>
         <td><?php echo ucwords($row['emp_middle_name']); ?></td>
         <td><?php echo ucwords($row['emp_lastname']); ?></td>
         <td><?php echo ucwords($row['job_title_code']); ?></td>
         <td></td>
         <td></td>
         <td></td>
         <td class="pull-right">
            <a href="editpersonal.php?id=<?php echo $row['emp_number']; ?>" class="btn btn-info btn-xs">
              <span class = "glyphicon glyphicon-pencil">
              </span>&nbsp;&nbsp;Edit
            </a>

            <a href="emplist.php?delete=<?php echo $row['emp_number']; ?>" 
              class="btn btn-danger btn-xs" onclick="return confirm('Are You Sure You Delete This Record')">
              <span class = "glyphicon glyphicon-trash">
              </span>&nbsp;&nbsp;Delete
            </a>
         </td>
        </tr> 
         <?php       
              }
            }
          }
          ?>
       </table>
    </div>
    </div>
  </div>
</section>
</div>
  <!--/////////////////////////////Control Sidebar///////////////////////-->
  <aside class="control-sidebar control-sidebar-dark">
      <div class="tab-pane" id="control-sidebar-home-tab"></div>
  </aside>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017 <a href="#"></a>All rights
    reserved.
  </footer>
</div>
<script src = "../../bootstrap/js/bootstrap.min.js"></script>
<script src="../../plugins/materialize-css/js/materialize.js"></script>
<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script src="../../dist/js/material.min.js"></script>
<script src="../../dist/js/ripples.min.js"></script>
<script>$.material.init();</script>
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="../../plugins/fastclick/fastclick.js"></script>
<script src="../../dist/js/app.min.js"></script>
<script src="../../dist/js/demo.js"></script>
<script src="../script.js"></script>
</body>
</html>
