<?php
session_start();
$err ="";
include('connection/connect.php');
if (isset($_POST['submit'])) {
  if (empty($_POST['username'])||empty($_POST['password'])) {
$err = "Invalid Username or Password!";
  }
  else {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    $que = "SELECT * FROM hr_user WHERE user_name = '$username' AND user_password = md5('$password') AND user_role_id = '1'";
    $res = mysqli_query($con, $que);
    if (mysqli_num_rows($res) == 1) {
    $_SESSION['username']=$username;
    header('location: adminhome.php');
    }
    else {
     $err = "Invalid Username or Password!";
    }
  }

}
else if (isset($_POST['empsubmit'])) {
   if (empty($_POST['empusername'])||empty($_POST['emppassword'])) {
$err = "Invalid Username or Password!";
  }
  else {
    $empusername = mysqli_real_escape_string($con, $_POST['empusername']);
    $emppassword = mysqli_real_escape_string($con, $_POST['emppassword']);
    $que = "SELECT * FROM hr_user WHERE user_name = '$empusername' AND user_password = md5('$emppassword') AND user_role_id='2'";
    $res = mysqli_query($con, $que);
    if (mysqli_num_rows($res) == 1) {
    $_SESSION['empusername']=$username;
    header('location: emphome.php');
    }
    else {
     $err = 'Invalid Username or Password!';
     echo "red";
    }
  }
}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Amhara Mass Media agency</title>
     <link style="text/css" rel="stylesheet" href="login/css/style.css">
<style>
  body{
    background-image: url('login/image/bg2.jpg');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
  }
  .error{
    text-align: center;
    color: red;
    font-size: 20px;
    margin-bottom: -50px;
  }
</style>
</head>
<body >
<div class="materialContainer">
   <div class="box">
      <div class="title"><center>ADMIN LOGIN HERE</center></div>
   
      <form action="" method="post">
      <div class="input">
         <label for="name">Username</label>
         <input type="text" name="username" id="name" required>
         <span class="spin"></span>
      </div>

      <div class="input" style="margin-bottom:20px">
         <label for="pass">Password</label>
         <input type="password" name="password" id="pass" required>
         <span class="spin"></span>
      </div>
      <div class = "error">
        <label><?php echo $err; ?></label>
      </div>
      <div class="button">
         <button type="submit" name="submit"><span>Login</span></i></button>
      </div>
    </form>
   </div>

   <div class="overbox">
      <div class="material-button alt-2"><span class="shape"></span></div>
      <div class="title"><center>EMPLOYEE LOGIN HERE</center></div>
   <form action="" method="post">
      <div class="input">
         <label for="regname">Username</label>
         <input type="text" name="empusername" id="regname" required>
         <span class="spin"></span>
      </div>
      <div class="input">
         <label for="regpass">Password</label>
         <input type="password" name="emppassword" id="regpass" required>
         <span class="spin"></span>
      </div>
      <div class="button">
         <button type="submit" name="empsubmit"><span>Login</span></button>
      </div>
    </form>
   </div>
</div>
  <script src='login/js/jquery-3.2.1.js'></script>
  <script  src="login/js/index.js"></script>
</body>
</html>
