<?php
$server = 'localhost';
$user = 'root';
$pass = '';
$database = 'hr';
 $con = mysqli_connect($server,$user,$pass,$database);
 ?>
